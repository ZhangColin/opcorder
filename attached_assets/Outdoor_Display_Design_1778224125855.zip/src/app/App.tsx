import { useState, useEffect, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, ReferenceLine,
} from 'recharts';

// ─── 数据 ────────────────────────────────────────────────────────────────────

const trendData = [
  { t: '00', v: 12 },
  { t: '03', v: 8 },
  { t: '06', v: 25 },
  { t: '09', v: 78 },
  { t: '12', v: 95 },
  { t: '15', v: 110 },
  { t: '18', v: 142 },
  { t: '21', v: 88 },
  { t: '24', v: 45 },
];

const orders = [
  { title: '庆东成区工业园区清洁保洁服务项目', time: '2分钟前', status: 'new',       amount: '8.2万' },
  { title: '高新物业园区绿化养护环境维护项目', time: '5分钟前', status: 'reviewing', amount: '12.5万' },
  { title: '城市街道亮化维修维护服务采购项目', time: '8分钟前', status: 'done',      amount: '6.8万' },
  { title: '商务街区停车场运营管理外包项目',   time: '12分钟前', status: 'new',      amount: '15.3万' },
  { title: '医院后勤保障及安保服务集中采购',   time: '15分钟前', status: 'reviewing', amount: '23.1万' },
  { title: '政务中心综合物业运营管理项目',     time: '18分钟前', status: 'done',      amount: '9.7万' },
];

const news = [
  { text: '21家OPC企业通过第三季度达标审理',      time: '09:45', type: 'award'  },
  { text: '高新区工业园区环境维护项目成功签约',    time: '09:23', type: 'sign'   },
  { text: '平台Q3资质审核工作正式启动',            time: '09:12', type: 'review' },
  { text: '本月订单审查97项，创平台历史新高',      time: '08:56', type: 'award'  },
  { text: '智能合同审核功能上线，效率提升40%',     time: '08:30', type: 'system' },
  { text: '月度数据报告已发布，审查总金3.9万元',   time: '08:00', type: 'report' },
  { text: '医院后勤保障服务项目招标文件正式发布',  time: '07:45', type: 'sign'   },
  { text: '新增3家OPC企业完成平台资质认证',        time: '07:20', type: 'review' },
];

// ─── 颜色常量 ─────────────────────────────────────────────────────────────────

const C = {
  cyan:   '#00d4ff',
  purple: '#a78bfa',
  green:  '#22d3a5',
  amber:  '#fbbf24',
  red:    '#f87171',
  blue:   '#60a5fa',
  bg:     '#040d1c',
  card:   '#071525',
  card2:  '#0a1e35',
  border: '#1a3a58',
};

// ─── 数字计数动画 ─────────────────────────────────────────────────────────────

function useCounter(target: number, delay = 0) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    const timeout = setTimeout(() => {
      const start = Date.now();
      const dur = 1400;
      const tick = () => {
        const p = Math.min((Date.now() - start) / dur, 1);
        const e = 1 - Math.pow(1 - p, 3);
        setVal(Math.round(e * target));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }, delay);
    return () => clearTimeout(timeout);
  }, [target, delay]);
  return val;
}

// ─── 自动滚动容器 ─────────────────────────────────────────────────────────────

function AutoScroll({
  items,
  itemHeight,
  gap = 0,
  speed = 1,
  renderItem,
}: {
  items: unknown[];
  itemHeight: number;
  gap?: number;
  speed?: number;
  renderItem: (item: unknown, idx: number) => ReactNode;
}) {
  const doubled = [...items, ...items];
  const unitH = itemHeight + gap;
  const totalH = items.length * unitH;

  return (
    <div style={{ height: '100%', overflow: 'hidden', position: 'relative' }}>
      <motion.div
        animate={{ y: [0, -totalH] }}
        transition={{
          duration: items.length * (3.2 / speed),
          ease: 'linear',
          repeat: Infinity,
          repeatType: 'loop',
        }}
      >
        {doubled.map((item, i) => (
          <div key={i} style={{ height: calcItemH(itemHeight, gap, i, items.length) }}>
            {renderItem(item, i % items.length)}
          </div>
        ))}
      </motion.div>
    </div>
  );
}

function calcItemH(itemHeight: number, gap: number, i: number, len: number) {
  if ((i + 1) % len === 0) return itemHeight;
  return itemHeight + gap;
}

// ─── 分区标题 ────────────────────────────────────────────────────────────────

function SectionTitle({ title, sub }: { title: string; sub?: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
      <div
        style={{
          width: 3, height: 14, borderRadius: 2,
          background: `linear-gradient(180deg, ${C.cyan}, #0055aa)`,
          boxShadow: `0 0 8px ${C.cyan}80`,
          flexShrink: 0,
        }}
      />
      <span style={{ fontSize: 12, color: '#7bc4dc', letterSpacing: '0.08em', fontWeight: 600 }}>
        {title}
      </span>
      <div style={{ flex: 1, height: 1, background: `linear-gradient(90deg, ${C.cyan}30, transparent)` }} />
      {sub && <span style={{ fontSize: 9, color: '#2a4a60' }}>{sub}</span>}
    </div>
  );
}

// ─── 大指标卡 ────────────────────────────────────────────────────────────────

function BigCard({
  label, value, unit, color, bg,
}: {
  label: string; value: string | number; unit?: string; color: string; bg: string;
}) {
  return (
    <div
      style={{
        background: bg,
        border: `1px solid ${color}28`,
        borderRadius: 10,
        padding: '10px 12px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* top-right corner bracket */}
      <div style={{
        position: 'absolute', top: 0, right: 0,
        width: 18, height: 18,
        borderTop: `2px solid ${color}55`,
        borderRight: `2px solid ${color}55`,
        borderRadius: '0 8px 0 0',
      }} />
      {/* bottom-left corner bracket */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0,
        width: 12, height: 12,
        borderBottom: `1px solid ${color}30`,
        borderLeft: `1px solid ${color}30`,
        borderRadius: '0 0 0 6px',
      }} />
      <div style={{ fontSize: 10, color: '#4a7090', marginBottom: 5, letterSpacing: '0.04em' }}>
        {label}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
        <span style={{
          fontSize: 28, color, fontWeight: 700, lineHeight: 1,
          textShadow: `0 0 18px ${color}70`,
        }}>
          {value}
        </span>
        {unit && (
          <span style={{ fontSize: 11, color: `${color}90`, fontWeight: 500 }}>{unit}</span>
        )}
      </div>
    </div>
  );
}

// ─── 小指标卡 ────────────────────────────────────────────────────────────────

function SmallCard({
  label, value, unit, color, sub,
}: {
  label: string; value: string | number; unit?: string; color: string; sub?: string;
}) {
  return (
    <div
      style={{
        background: C.card,
        border: `1px solid ${color}22`,
        borderRadius: 9,
        padding: '9px 10px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 2,
        background: `linear-gradient(90deg, transparent, ${color}50, transparent)`,
      }} />
      <div style={{ fontSize: 9, color: '#4a6880', marginBottom: 4 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 2 }}>
        <span style={{
          fontSize: 22, color, fontWeight: 700, lineHeight: 1,
          textShadow: `0 0 14px ${color}60`,
        }}>
          {value}
        </span>
        {unit && <span style={{ fontSize: 9, color: `${color}80` }}>{unit}</span>}
      </div>
      {sub && <div style={{ fontSize: 8, color: '#2a4a60', marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// 第一屏：核心指标
// ═══════════════════════════════════════════════════════════════════════════════

function Screen1() {
  const users = useCounter(1553, 100);
  const opcs  = useCounter(1454, 200);

  return (
    <motion.div
      key="s1"
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -30 }}
      transition={{ duration: 0.45, ease: 'easeInOut' }}
      style={{ height: '100%', padding: '10px 12px 8px', display: 'flex', flexDirection: 'column', gap: 8 }}
    >
      <SectionTitle title="核心指标" sub="数据总览" />

      {/* 两大核心数字 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <BigCard label="平台用户数" value={users.toLocaleString()} color={C.cyan}
          bg={`linear-gradient(135deg, #0a2040 0%, ${C.card} 100%)`} />
        <BigCard label="OPC 数量" value={opcs.toLocaleString()} color={C.purple}
          bg={`linear-gradient(135deg, #150a30 0%, ${C.card} 100%)`} />
      </div>

      {/* 审查总金额 - 突出展示 */}
      <div
        style={{
          background: `linear-gradient(135deg, #0f2a1e 0%, #071516 100%)`,
          border: `1px solid ${C.green}28`,
          borderRadius: 10,
          padding: '10px 14px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* 背景光晕 */}
        <div style={{
          position: 'absolute', right: -20, top: -20,
          width: 80, height: 80, borderRadius: '50%',
          background: `${C.green}08`,
        }} />
        <div>
          <div style={{ fontSize: 10, color: '#4a8070', marginBottom: 4, letterSpacing: '0.05em' }}>
            审查总金额
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
            <span style={{
              fontSize: 32, fontWeight: 700, color: C.green, lineHeight: 1,
              textShadow: `0 0 20px ${C.green}80`,
            }}>3.9</span>
            <span style={{ fontSize: 13, color: `${C.green}90` }}>万元</span>
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 9, color: '#2a6050' }}>较上月</div>
          <div style={{ fontSize: 13, color: C.green, fontWeight: 600 }}>↑ 12%</div>
        </div>
      </div>

      {/* 四项辅助指标 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7, flex: 1 }}>
        <SmallCard label="累计审理" value="97"  unit="项" color={C.amber}  sub="本周期" />
        <SmallCard label="达标审理" value="21"  unit="项" color={C.green}  sub="已通过" />
        <SmallCard label="待审核"   value="6"   unit="项" color={C.red}    sub="待处理" />
        <SmallCard label="资质审核" value="3"   unit="项" color={C.blue}   sub="进行中" />
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// 第二屏：订单趋势
// ═══════════════════════════════════════════════════════════════════════════════

function Screen2() {
  return (
    <motion.div
      key="s2"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      transition={{ duration: 0.45, ease: 'easeInOut' }}
      style={{ height: '100%', padding: '10px 12px 8px', display: 'flex', flexDirection: 'column' }}
    >
      <SectionTitle title="订单趋势" sub="24小时" />

      {/* 三格今日统计 */}
      <div
        style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 7, marginBottom: 10,
        }}
      >
        {[
          { label: '今日订单', val: '142', color: C.cyan },
          { label: '审查中',   val: '28',  color: C.amber },
          { label: '已完成',   val: '114', color: C.green },
        ].map((s) => (
          <div
            key={s.label}
            style={{
              background: C.card,
              border: `1px solid ${s.color}22`,
              borderRadius: 9, padding: '8px 6px', textAlign: 'center',
              position: 'relative', overflow: 'hidden',
            }}
          >
            <div style={{
              position: 'absolute', top: 0, left: 0, right: 0, height: 2,
              background: `linear-gradient(90deg, transparent, ${s.color}60, transparent)`,
            }} />
            <div style={{ fontSize: 9, color: '#4a7090', marginBottom: 4 }}>{s.label}</div>
            <div style={{
              fontSize: 22, fontWeight: 700, color: s.color, lineHeight: 1,
              textShadow: `0 0 14px ${s.color}60`,
            }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* 图表区域 - 给足高度 */}
      <div
        style={{
          flex: 1,
          background: `linear-gradient(180deg, #071828 0%, #040e1c 100%)`,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
          padding: '10px 6px 6px 2px',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <div style={{ fontSize: 9, color: '#2a4a60', marginBottom: 6, paddingLeft: 8, letterSpacing: '0.05em' }}>
          24小时订单走势
        </div>
        <div style={{ flex: 1, minHeight: 0 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={trendData}
              barSize={16}
              margin={{ top: 4, right: 6, bottom: 0, left: -20 }}
            >
              <defs>
                <linearGradient id="barGradActive" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00d4ff" stopOpacity={1} />
                  <stop offset="100%" stopColor="#0055aa" stopOpacity={0.8} />
                </linearGradient>
                <linearGradient id="barGradNormal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00d4ff" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#0044aa" stopOpacity={0.3} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="t"
                tick={{ fill: '#3a5870', fontSize: 8 }}
                tickLine={false}
                axisLine={{ stroke: `${C.border}60` }}
                interval={1}
              />
              <YAxis
                tick={{ fill: '#3a5870', fontSize: 8 }}
                tickLine={false}
                axisLine={false}
                tickCount={4}
              />
              <ReferenceLine
                y={0}
                stroke={`${C.border}40`}
              />
              <Bar dataKey="v" radius={[4, 4, 0, 0]}>
                {trendData.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={entry.v === Math.max(...trendData.map((x) => x.v))
                      ? 'url(#barGradActive)'
                      : 'url(#barGradNormal)'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        {/* 峰值标注 */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'flex-end',
          paddingRight: 8, marginTop: 4, gap: 8,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: C.cyan }} />
            <span style={{ fontSize: 8, color: '#3a6080' }}>峰值 18:00 / 142单</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// 第三屏：实时订单动态
// ═══════════════════════════════════════════════════════════════════════════════

const STATUS_MAP = {
  new:       { label: '新订单', color: C.cyan  },
  reviewing: { label: '审查中', color: C.amber },
  done:      { label: '已完成', color: C.green },
};

const ORDER_ITEM_H = 62;
const ORDER_GAP = 7;

function Screen3() {
  return (
    <motion.div
      key="s3"
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -30 }}
      transition={{ duration: 0.45, ease: 'easeInOut' }}
      style={{ height: '100%', padding: '10px 12px 8px', display: 'flex', flexDirection: 'column' }}
    >
      <SectionTitle title="实时订单动态" sub="滚动播报" />

      {/* 状态统计横条 */}
      <div style={{
        display: 'flex', gap: 6, marginBottom: 10,
      }}>
        {Object.entries(STATUS_MAP).map(([key, s]) => {
          const count = orders.filter((o) => o.status === key).length;
          return (
            <div
              key={key}
              style={{
                flex: 1, background: C.card, borderRadius: 7,
                padding: '5px 6px', textAlign: 'center',
                border: `1px solid ${s.color}22`,
              }}
            >
              <div style={{ fontSize: 8, color: '#3a5870', marginBottom: 2 }}>{s.label}</div>
              <div style={{ fontSize: 17, fontWeight: 700, color: s.color, lineHeight: 1 }}>{count}</div>
            </div>
          );
        })}
      </div>

      {/* 滚动订单列表 */}
      <div style={{ flex: 1, minHeight: 0 }}>
        <AutoScroll
          items={orders}
          itemHeight={ORDER_ITEM_H}
          gap={ORDER_GAP}
          speed={0.85}
          renderItem={(item) => {
            const o = item as typeof orders[0];
            const s = STATUS_MAP[o.status as keyof typeof STATUS_MAP];
            return (
              <div style={{
                height: ORDER_ITEM_H,
                background: C.card,
                border: `1px solid ${C.border}`,
                borderLeft: `3px solid ${s.color}`,
                borderRadius: 9,
                padding: '8px 10px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                position: 'relative',
                overflow: 'hidden',
              }}>
                {/* 背景光晕 */}
                <div style={{
                  position: 'absolute', left: -10, top: '50%', transform: 'translateY(-50%)',
                  width: 40, height: 40, borderRadius: '50%',
                  background: `${s.color}06`,
                }} />
                <p style={{
                  fontSize: 11, color: '#c0d8e8', lineHeight: 1.4,
                  overflow: 'hidden',
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  margin: 0,
                }}>
                  {o.title}
                </p>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 9, color: '#3a5870' }}>{o.time}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 10, color: C.green, fontWeight: 600 }}>{o.amount}</span>
                    <span style={{
                      fontSize: 8, padding: '2px 6px', borderRadius: 4,
                      background: `${s.color}18`,
                      color: s.color, fontWeight: 600,
                    }}>
                      {s.label}
                    </span>
                  </div>
                </div>
              </div>
            );
          }}
        />
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// 第四屏：平台动态
// ═══════════════════════════════════════════════════════════════════════════════

const NEWS_ICON: Record<string, string> = {
  award:  '🏆',
  sign:   '📋',
  review: '🔍',
  system: '⚡',
  report: '📊',
};
const NEWS_COLOR: Record<string, string> = {
  award:  C.amber,
  sign:   C.cyan,
  review: C.purple,
  system: C.green,
  report: C.blue,
};

const NEWS_ITEM_H = 58;
const NEWS_GAP = 7;

function Screen4() {
  return (
    <motion.div
      key="s4"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      transition={{ duration: 0.45, ease: 'easeInOut' }}
      style={{ height: '100%', padding: '10px 12px 8px', display: 'flex', flexDirection: 'column' }}
    >
      <SectionTitle title="平台动态" sub="最新资讯" />

      {/* 实时标签 */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        marginBottom: 10, padding: '6px 10px',
        background: C.card,
        border: `1px solid ${C.border}`,
        borderRadius: 8,
      }}>
        <div style={{
          width: 7, height: 7, borderRadius: '50%', background: C.red,
          boxShadow: `0 0 6px ${C.red}`,
          animation: 'pulse 1.5s ease-in-out infinite',
        }} />
        <span style={{ fontSize: 10, color: '#4a7090' }}>LIVE</span>
        <div style={{ width: 1, height: 10, background: C.border }} />
        <span style={{ fontSize: 10, color: '#7ab8d0' }}>今日更新 · 8 条动态</span>
      </div>

      {/* 滚动新闻列表 */}
      <div style={{ flex: 1, minHeight: 0 }}>
        <AutoScroll
          items={news}
          itemHeight={NEWS_ITEM_H}
          gap={NEWS_GAP}
          speed={0.75}
          renderItem={(item) => {
            const n = item as typeof news[0];
            const color = NEWS_COLOR[n.type] || C.cyan;
            return (
              <div style={{
                height: NEWS_ITEM_H,
                background: C.card,
                border: `1px solid ${C.border}`,
                borderRadius: 9,
                padding: '9px 10px',
                display: 'flex',
                alignItems: 'flex-start',
                gap: 8,
                position: 'relative',
                overflow: 'hidden',
              }}>
                <div style={{
                  position: 'absolute', top: 0, left: 0, right: 0, height: 1,
                  background: `linear-gradient(90deg, transparent, ${color}30, transparent)`,
                }} />
                {/* 图标区 */}
                <div style={{
                  width: 28, height: 28, borderRadius: 7, flexShrink: 0,
                  background: `${color}15`,
                  border: `1px solid ${color}25`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 14,
                }}>
                  {NEWS_ICON[n.type] || '📌'}
                </div>
                {/* 内容 */}
                <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <p style={{
                    fontSize: 11, color: '#bcd4e8', lineHeight: 1.4, margin: 0,
                    overflow: 'hidden',
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                  }}>
                    {n.text}
                  </p>
                  <span style={{ fontSize: 9, color: '#2a4a60' }}>{n.time}</span>
                </div>
              </div>
            );
          }}
        />
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// 主应用
// ═══════════════════════════════════════════════════════════════════════════════

export default function App() {
  const [screen, setScreen] = useState(0);
  const [time, setTime] = useState(new Date());
  const totalScreens = 4;

  // 实时时钟
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // 自动切屏
  useEffect(() => {
    const t = setInterval(() => setScreen((s) => (s + 1) % totalScreens), 7000);
    return () => clearInterval(t);
  }, []);

  const timeStr = time.toLocaleTimeString('zh-CN', { hour12: false });
  const dateStr = time.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });

  const screenNames = ['核心指标', '订单趋势', '订单动态', '平台动态'];

  return (
    <div
      style={{
        width: 246,
        height: 466,
        background: C.bg,
        overflow: 'hidden',
        position: 'relative',
        fontFamily: '"PingFang SC", "Noto Sans SC", "Microsoft YaHei", sans-serif',
        color: '#ffffff',
      }}
    >
      {/* ── 扫描线纹理 ── */}
      <div
        style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 30,
          opacity: 0.025,
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,1) 2px, rgba(255,255,255,1) 3px)',
          backgroundSize: '100% 3px',
        }}
      />

      {/* ── 背景光晕 ── */}
      <div style={{
        position: 'absolute', top: -40, left: -40,
        width: 200, height: 200, borderRadius: '50%',
        background: `radial-gradient(circle, ${C.cyan}06, transparent 70%)`,
        pointerEvents: 'none', zIndex: 0,
      }} />
      <div style={{
        position: 'absolute', bottom: -40, right: -40,
        width: 160, height: 160, borderRadius: '50%',
        background: `radial-gradient(circle, ${C.purple}07, transparent 70%)`,
        pointerEvents: 'none', zIndex: 0,
      }} />

      {/* ── 顶部标题栏 ── */}
      <div
        style={{
          position: 'absolute', top: 0, left: 0, right: 0,
          height: 36, zIndex: 20,
          background: `linear-gradient(90deg, #0a1e3a 0%, #071525 100%)`,
          borderBottom: `1px solid ${C.cyan}18`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 12px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {/* 脉冲点 */}
          <div style={{ position: 'relative', width: 8, height: 8 }}>
            <div style={{
              position: 'absolute', inset: 0, borderRadius: '50%',
              background: C.cyan,
              boxShadow: `0 0 8px ${C.cyan}`,
            }} />
            <div style={{
              position: 'absolute', inset: -3, borderRadius: '50%',
              border: `1px solid ${C.cyan}40`,
              animation: 'ping 1.5s ease-in-out infinite',
            }} />
          </div>
          <span style={{
            fontSize: 11, color: C.cyan, fontWeight: 600,
            letterSpacing: '0.06em',
            textShadow: `0 0 12px ${C.cyan}60`,
          }}>
            OPC 接单平台
          </span>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 11, color: '#5a88a8', fontVariantNumeric: 'tabular-nums', lineHeight: 1.2 }}>
            {timeStr}
          </div>
          <div style={{ fontSize: 8, color: '#2a4a60', lineHeight: 1 }}>{dateStr}</div>
        </div>
      </div>

      {/* ── 屏幕内容区 ── */}
      <div
        style={{
          position: 'absolute', top: 36, left: 0, right: 0,
          bottom: 20, zIndex: 10,
        }}
      >
        <AnimatePresence mode="wait">
          {screen === 0 && <Screen1 />}
          {screen === 1 && <Screen2 />}
          {screen === 2 && <Screen3 />}
          {screen === 3 && <Screen4 />}
        </AnimatePresence>
      </div>

      {/* ── 底部指示条 ── */}
      <div
        style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          height: 20, zIndex: 20,
          background: '#030b18',
          borderTop: `1px solid ${C.border}40`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          gap: 10,
        }}
      >
        {/* 当前屏幕名 */}
        <span style={{ fontSize: 8, color: '#2a4a60' }}>
          {screenNames[screen]}
        </span>
        {/* 点状指示器 */}
        <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
          {[0, 1, 2, 3].map((i) => (
            <motion.div
              key={i}
              animate={{
                width: i === screen ? 18 : 5,
                opacity: i === screen ? 1 : 0.25,
              }}
              transition={{ duration: 0.35, ease: 'easeInOut' }}
              style={{
                height: 4, borderRadius: 3,
                background: i === screen ? C.cyan : '#3a5870',
                boxShadow: i === screen ? `0 0 6px ${C.cyan}80` : 'none',
              }}
            />
          ))}
        </div>
      </div>

      {/* CSS 动画注入 */}
      <style>{`
        @keyframes ping {
          0%, 100% { transform: scale(1); opacity: 0.6; }
          50% { transform: scale(1.8); opacity: 0; }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}