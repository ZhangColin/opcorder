
  # Outdoor Display Design

  This is a code bundle for Outdoor Display Design. The original project is available at https://www.figma.com/design/IPWrwF7FrTwEZXt15gTP20/Outdoor-Display-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  