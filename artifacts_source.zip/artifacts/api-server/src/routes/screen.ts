import { logger } from "../lib/logger";
import { Router, type IRouter } from "express";
import { db, usersTable, demandsTable, ordersTable, portfoliosTable } from "@workspace/db";
import { eq, gte, sql, count, and, inArray, desc } from "drizzle-orm";
import { requireAdmin, requirePermission } from "../middleware/adminAuth";

const router: IRouter = Router();

function relativeTime(d: Date): string {
  const diff = Date.now() - d.getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min}分钟前`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}小时前`;
  return `${Math.floor(hr / 24)}天前`;
}

function daysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  d.setHours(0, 0, 0, 0);
  return d;
}

function dateKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function buildDailyBuckets(days: number): Record<string, number> {
  const buckets: Record<string, number> = {};
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    buckets[dateKey(d)] = 0;
  }
  return buckets;
}

function maskName(name: string | null | undefined): string {
  if (!name) return '***';
  if (name.length <= 1) return name;
  return name[0] + '**';
}

function formatBudget(min: number, max: number): string {
  const fmt = (n: number) => {
    if (n >= 10000) return `${(n / 10000).toFixed(1)}万`;
    if (n >= 1000) return `${(n / 1000).toFixed(0)}k`;
    return `${Math.round(n)}`;
  };
  if (!min && !max) return '面议';
  if (!min && max) return `≤¥${fmt(max)}`;
  if (min && !max) return `¥${fmt(min)}+`;
  return `¥${fmt(min)}–${fmt(max)}`;
}

const CANONICAL_TYPES = new Set(["education", "software", "marketing", "content", "other"]);
const DEMAND_TYPE_LABELS: Record<string, string> = {
  education:  "教育培训",
  software:   "软件开发",
  marketing:  "营销推广",
  content:    "内容创作",
  other:      "其它",
};

router.get("/screen", requireAdmin, requirePermission("screen"), async (_req, res) => {
  try {
    const DAYS = 14;
    const since14 = daysAgo(DAYS);

    /* ── KPIs ──────────────────────────────────────────── */

    const usersByRole = await db
      .select({ role: usersTable.role, cnt: count() })
      .from(usersTable)
      .where(eq(usersTable.status, "active"))
      .groupBy(usersTable.role);

    const roleMap: Record<string, number> = {};
    for (const r of usersByRole) roleMap[r.role] = Number(r.cnt);

    const totalUsers  = Object.values(roleMap).reduce((a, b) => a + b, 0);
    const opcCount    = roleMap["opc"] ?? 0;
    const pubCount    = roleMap["publisher"] ?? 0;

    const POSITIVE_DEMAND_STATUSES = ["published", "matched", "in_progress", "pending_acceptance", "completed"] as const;
    const demandByStatus = await db
      .select({ status: demandsTable.status, cnt: count() })
      .from(demandsTable)
      .groupBy(demandsTable.status);

    const demandStatusMap: Record<string, number> = {};
    for (const d of demandByStatus) demandStatusMap[d.status] = Number(d.cnt);

    const publishedDemands = (POSITIVE_DEMAND_STATUSES as readonly string[])
      .reduce((sum, s) => sum + (demandStatusMap[s] ?? 0), 0);

    const orderByStatus = await db
      .select({ status: ordersTable.status, cnt: count() })
      .from(ordersTable)
      .groupBy(ordersTable.status);

    const orderStatusMap: Record<string, number> = {};
    for (const o of orderByStatus) orderStatusMap[o.status] = Number(o.cnt);

    const inProgressOrders = (orderStatusMap["in_progress"] ?? 0) + (orderStatusMap["pending_acceptance"] ?? 0);
    const completedOrders  = orderStatusMap["completed"] ?? 0;
    const totalOrders      = Object.values(orderStatusMap).reduce((a, b) => a + b, 0);
    const completionRate   = totalOrders > 0 ? Math.round((completedOrders / totalOrders) * 100) : 0;

    const [settled] = await db
      .select({ total: sql<number>`COALESCE(SUM(${ordersTable.amount}), 0)` })
      .from(ordersTable)
      .where(eq(ordersTable.status, "completed"));
    const totalSettled = Number(settled.total) || 0;

    /* ── Time series (last 14 days) ────────────────────── */

    const newUserRows = await db
      .select({
        day: sql<string>`DATE(${usersTable.createdAt})`,
        cnt: count(),
      })
      .from(usersTable)
      .where(gte(usersTable.createdAt, since14))
      .groupBy(sql`DATE(${usersTable.createdAt})`);

    const newDemandRows = await db
      .select({
        day: sql<string>`DATE(${demandsTable.createdAt})`,
        cnt: count(),
      })
      .from(demandsTable)
      .where(and(
        gte(demandsTable.createdAt, since14),
        inArray(demandsTable.status, POSITIVE_DEMAND_STATUSES),
      ))
      .groupBy(sql`DATE(${demandsTable.createdAt})`);

    const newOrderRows = await db
      .select({
        day: sql<string>`DATE(${ordersTable.createdAt})`,
        cnt: count(),
      })
      .from(ordersTable)
      .where(gte(ordersTable.createdAt, since14))
      .groupBy(sql`DATE(${ordersTable.createdAt})`);

    const userBuckets   = buildDailyBuckets(DAYS);
    const demandBuckets = buildDailyBuckets(DAYS);
    const orderBuckets  = buildDailyBuckets(DAYS);

    for (const r of newUserRows)   if (r.day in userBuckets)   userBuckets[r.day]   = Number(r.cnt);
    for (const r of newDemandRows) if (r.day in demandBuckets) demandBuckets[r.day] = Number(r.cnt);
    for (const r of newOrderRows)  if (r.day in orderBuckets)  orderBuckets[r.day]  = Number(r.cnt);

    const dates = Object.keys(userBuckets).sort();
    const timeSeries = dates.map(date => ({
      date,
      label: date.slice(5),
      newUsers:   userBuckets[date],
      newDemands: demandBuckets[date],
      newOrders:  orderBuckets[date],
    }));

    /* ── Cumulative OPC / Publisher series (14 days) ───── */

    const allOpcDates = await db
      .select({ createdAt: usersTable.createdAt })
      .from(usersTable)
      .where(and(eq(usersTable.role, "opc"), eq(usersTable.status, "active")));

    const allPubDates = await db
      .select({ createdAt: usersTable.createdAt })
      .from(usersTable)
      .where(and(eq(usersTable.role, "publisher"), eq(usersTable.status, "active")));

    const cumulativeSeries = dates.map(date => {
      const dayEnd = new Date(date + "T23:59:59.999Z");
      const totalOpc       = allOpcDates.filter(u => new Date(u.createdAt) <= dayEnd).length;
      const totalPublisher = allPubDates.filter(u => new Date(u.createdAt) <= dayEnd).length;
      return { date, label: date.slice(5), totalOpc, totalPublisher };
    });

    /* ── Chart: demand status distribution ─────────────── */

    const DEMAND_STATUS_LABELS: Record<string, string> = {
      published:          "已发布",
      matched:            "匹配中",
      in_progress:        "进行中",
      pending_acceptance: "待验收",
      completed:          "已完成",
    };
    const demandStatusChart = POSITIVE_DEMAND_STATUSES.map(s => ({
      status: s,
      label:  DEMAND_STATUS_LABELS[s] ?? s,
      value:  demandStatusMap[s] ?? 0,
    }));

    /* ── Chart: order type distribution ─────────────────── */

    const orderTypeRows = await db
      .select({ type: demandsTable.type, cnt: count() })
      .from(ordersTable)
      .innerJoin(demandsTable, eq(ordersTable.demandId, demandsTable.id))
      .groupBy(demandsTable.type);

    const typeCountMap: Record<string, number> = {};
    for (const row of orderTypeRows) {
      const key = CANONICAL_TYPES.has(row.type) ? row.type : "other";
      typeCountMap[key] = (typeCountMap[key] ?? 0) + Number(row.cnt);
    }

    const orderTypeChart = (["education", "software", "marketing", "content", "other"] as const).map(t => ({
      type:  t,
      label: DEMAND_TYPE_LABELS[t],
      value: typeCountMap[t] ?? 0,
    }));

    /* ── Demand list (for top panel) ─────────────────────── */

    const DEMAND_STATUS_SHORT_LABELS: Record<string, string> = {
      published:          "已发布",
      matched:            "匹配中",
      in_progress:        "进行中",
      pending_acceptance: "待验收",
      completed:          "已完成",
    };

    const recentDemandsRaw = await db
      .select({
        id:         demandsTable.id,
        title:      demandsTable.title,
        budgetMin:  demandsTable.budgetMin,
        budgetMax:  demandsTable.budgetMax,
        status:     demandsTable.status,
        createdAt:  demandsTable.createdAt,
        nickname:   usersTable.nickname,
      })
      .from(demandsTable)
      .innerJoin(usersTable, eq(demandsTable.publisherId, usersTable.id))
      .where(inArray(demandsTable.status, POSITIVE_DEMAND_STATUSES))
      .orderBy(desc(demandsTable.createdAt))
      .limit(30);

    const demandList = recentDemandsRaw.map(d => ({
      id:           d.id,
      publisher:    maskName(d.nickname),
      title:        d.title,
      budget:       formatBudget(Number(d.budgetMin), Number(d.budgetMax)),
      status:       d.status,
      statusLabel:  DEMAND_STATUS_SHORT_LABELS[d.status] ?? d.status,
    }));

    /* ── Ticker events ───────────────────────────────────── */

    const recentOpcs = await db
      .select({ id: usersTable.id, nickname: usersTable.nickname, createdAt: usersTable.createdAt })
      .from(usersTable)
      .where(and(eq(usersTable.role, "opc"), eq(usersTable.status, "active")))
      .orderBy(desc(usersTable.createdAt))
      .limit(20);

    const recentOrders = await db
      .select({
        id: ordersTable.id,
        createdAt: ordersTable.createdAt,
        opcNickname: usersTable.nickname,
        demandTitle: demandsTable.title,
      })
      .from(ordersTable)
      .innerJoin(usersTable, eq(ordersTable.opcId, usersTable.id))
      .innerJoin(demandsTable, eq(ordersTable.demandId, demandsTable.id))
      .orderBy(desc(ordersTable.createdAt))
      .limit(20);

    const recentCerts = await db
      .select({
        id: portfoliosTable.id,
        applyLevel: portfoliosTable.applyLevel,
        reviewedAt: portfoliosTable.reviewedAt,
        nickname: usersTable.nickname,
      })
      .from(portfoliosTable)
      .innerJoin(usersTable, eq(portfoliosTable.userId, usersTable.id))
      .where(eq(portfoliosTable.levelApplyStatus, "approved"))
      .orderBy(desc(portfoliosTable.reviewedAt))
      .limit(15);

    const recentDemands = await db
      .select({ id: demandsTable.id, title: demandsTable.title, createdAt: demandsTable.createdAt, nickname: usersTable.nickname })
      .from(demandsTable)
      .innerJoin(usersTable, eq(demandsTable.publisherId, usersTable.id))
      .where(inArray(demandsTable.status, POSITIVE_DEMAND_STATUSES))
      .orderBy(desc(demandsTable.createdAt))
      .limit(20);

    /* ── Recent order list (structured, for miniscreen) ─── */

    const ORDER_STATUS_LABELS: Record<string, string> = {
      in_progress:        '进行中',
      pending_acceptance: '待验收',
      completed:          '已完成',
      closed:             '已关闭',
      disputed:           '争议中',
    };

    const orderListRows = await db
      .select({
        id:          ordersTable.id,
        title:       demandsTable.title,
        amount:      ordersTable.amount,
        status:      ordersTable.status,
        createdAt:   ordersTable.createdAt,
        opcNickname: usersTable.nickname,
      })
      .from(ordersTable)
      .innerJoin(demandsTable, eq(ordersTable.demandId, demandsTable.id))
      .innerJoin(usersTable,   eq(ordersTable.opcId,    usersTable.id))
      .orderBy(desc(ordersTable.createdAt))
      .limit(12);

    const recentOrderList = orderListRows.map(o => ({
      id:          o.id,
      title:       o.title,
      opcNickname: o.opcNickname,
      amount:      Number(o.amount),
      status:      o.status,
      statusLabel: ORDER_STATUS_LABELS[o.status] ?? o.status,
      timeAgo:     relativeTime(new Date(o.createdAt)),
    }));

    const ticker1 = [
      ...recentOpcs.map(u => ({ text: `欢迎 ${maskName(u.nickname)} 注册成为 OPC` })),
      ...recentOrders.map(o => ({ text: `恭喜 ${maskName(o.opcNickname)} 中标《${o.demandTitle}》项目` })),
    ].sort(() => Math.random() - 0.5);

    const ticker2 = [
      ...recentCerts.map(c => ({ text: `${maskName(c.nickname)} 成功晋升为 ${c.applyLevel} 级 OPC` })),
      ...recentDemands.map(d => ({ text: `${maskName(d.nickname)} 发布新需求《${d.title}》` })),
    ].sort(() => Math.random() - 0.5);

    return res.json({
      kpi: { totalUsers, opcCount, publisherCount: pubCount, publishedDemands, inProgressOrders, completedOrders, completionRate, totalSettled },
      timeSeries,
      cumulativeSeries,
      demandStatusChart,
      orderTypeChart,
      demandList,
      ticker1,
      ticker2,
      recentOrderList,
    });
  } catch (err) {
    logger.error({ err: err }, "Route handler error");
    return res.status(500).json({ error: "数据加载失败" });
  }
});

export default router;
